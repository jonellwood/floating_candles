-- Hogwarts Beams: standalone decorative structural timbers.
-- All meshes and textures are original; no Asuna-specific dependencies.
local mt = minetest
local mod = mt.get_current_modname()
local specs = dofile(mt.get_modpath(mod) .. "/geometry.lua")
local by_name = {}
local prefix = mod .. ":"
local part_group = "hogwarts_beam_part"

local function key(p) return p.x .. "," .. p.y .. "," .. p.z end
local function rotated(o, r)
    local x,y,z = o[1],o[2],o[3]
    if r == 1 then return {x=z,y=y,z=-x} end
    if r == 2 then return {x=-x,y=y,z=-z} end
    if r == 3 then return {x=-z,y=y,z=x} end
    return {x=x,y=y,z=z}
end
local function add(a,b) return {x=a.x+b.x,y=a.y+b.y,z=a.z+b.z} end
local function tell(player, message)
    if player then mt.chat_send_player(player:get_player_name(), "[Hogwarts Beams] " .. message) end
end
local function get_root(pos)
    local n = mt.get_node(pos)
    if by_name[n.name] then return pos, n end
    if mt.get_item_group(n.name,part_group) == 1 then
        local p = mt.deserialize(mt.get_meta(pos):get_string("root"))
        if type(p)=="table" and type(p.x)=="number" and type(p.y)=="number" and type(p.z)=="number" then
            local rn = mt.get_node(p)
            if by_name[rn.name] then return p,rn end
        end
    end
end
local function cells(root, spec, rotation)
    local out = {}
    for i,p in ipairs(spec.parts) do
        out[i] = {pos=add(root,rotated(p.offset,rotation)),part=p,index=i}
    end
    return out
end
local function allowed(list, player, oldroot)
    local name = player and player:get_player_name() or ""
    for _,cell in ipairs(list) do
        local p = cell.pos
        if mt.is_protected(p,name) then
            mt.record_protection_violation(p,name)
            return false,"The beam would touch a protected block."
        end
        local n = mt.get_node_or_nil(p)
        if not n or n.name == "ignore" then return false,"Some blocks are unloaded. Move closer and try again." end
        local own = false
        if oldroot then
            own = key(p)==key(oldroot) or
                (mt.get_item_group(n.name,part_group)==1 and
                 mt.get_meta(p):get_string("root_key")==key(oldroot))
        end
        -- Only air is replaced. Plants, liquids, existing beams and metadata survive.
        if n.name ~= "air" and not own then
            return false,"Clearance blocked at " .. mt.pos_to_string(p) .. ". Try a shorter beam or move its anchor."
        end
    end
    return true
end
local function clear_parts(root)
    local positions = mt.deserialize(mt.get_meta(root):get_string("parts")) or {}
    for _,p in ipairs(positions) do
        local n = mt.get_node(p)
        if mt.get_item_group(n.name,part_group)==1 and
            mt.get_meta(p):get_string("root_key")==key(root) then mt.remove_node(p) end
    end
end
local function write(root,spec,rotation,owner)
    mt.swap_node(root,{name=prefix..spec.id,param2=rotation})
    local positions = {}
    for _,cell in ipairs(cells(root,spec,rotation)) do
        if key(cell.pos) ~= key(root) then
            mt.set_node(cell.pos,{name=prefix.."part_"..spec.id.."_"..cell.index,param2=rotation})
            mt.get_meta(cell.pos):set_string("root",mt.serialize(root))
            mt.get_meta(cell.pos):set_string("root_key",key(root))
            mt.get_meta(cell.pos):set_string("infotext","Hogwarts Beam: dig here to remove the whole timber")
            positions[#positions+1] = cell.pos
        end
    end
    local meta=mt.get_meta(root)
    meta:set_string("parts",mt.serialize(positions))
    meta:set_string("owner",owner or "")
    meta:set_string("infotext",mt.registered_nodes[prefix..spec.id].description .. " | Mallet: rotate")
end
local function can_dig(root,player)
    local n=mt.get_node(root); local spec=by_name[n.name]
    if not spec then return false end
    -- Check all occupied cells, even when digging a distant end of the mesh.
    local ok,msg=allowed(cells(root,spec,n.param2%4),player,root)
    if not ok then tell(player,msg) end
    return ok
end
local function place(itemstack,player,pointed)
    if not player or not pointed or pointed.type~="node" then return itemstack end
    if not mt.check_player_privs(player:get_player_name(),{interact=true}) then return itemstack end
    local under = mt.get_node(pointed.under)
    local def = mt.registered_nodes[under.name]
    if def and def.on_rightclick and not player:get_player_control().sneak then
        return def.on_rightclick(pointed.under,under,player,itemstack,pointed) or itemstack
    end
    local root=pointed.above
    if under.name == "air" then root=pointed.under end
    local spec=by_name[itemstack:get_name()]
    local rotation=mt.dir_to_facedir(player:get_look_dir(),false)%4
    local ok,msg=allowed(cells(root,spec,rotation),player)
    if not ok then tell(player,msg); return itemstack end
    write(root,spec,rotation,player:get_player_name())
    if not mt.is_creative_enabled(player:get_player_name()) then itemstack:take_item() end
    return itemstack
end
local function turn(itemstack,player,pointed)
    if not player or not pointed or pointed.type~="node" then return itemstack end
    if not mt.check_player_privs(player:get_player_name(),{interact=true}) then return itemstack end
    local root,n=get_root(pointed.under)
    if not root then tell(player,"Point at a Hogwarts timber."); return itemstack end
    local spec=by_name[n.name]
    local direction=player:get_player_control().sneak and -1 or 1
    local rotation=(n.param2+direction)%4
    local ok,msg=allowed(cells(root,spec,n.param2%4),player,root)
    if ok then ok,msg=allowed(cells(root,spec,rotation),player,root) end
    if not ok then tell(player,msg); return itemstack end
    local owner=mt.get_meta(root):get_string("owner")
    clear_parts(root)
    write(root,spec,rotation,owner)
    return itemstack
end

local kind_labels={brace="45-degree Brace",horizontal="Horizontal Beam",post="Vertical Post"}
for _,spec in ipairs(specs) do
    local name=prefix..spec.id
    by_name[name]=spec
    local anchor_boxes
    for _,p in ipairs(spec.parts) do
        if p.offset[1]==0 and p.offset[2]==0 and p.offset[3]==0 then anchor_boxes=p.boxes end
    end
    local desc="Hogwarts "..(spec.size=="heavy" and "Heavy " or "Slim ")..kind_labels[spec.kind].." ("..spec.length.." block"..(spec.length==1 and "" or "s")..")"
    mt.register_node(name,{
        description=desc, drawtype="mesh", mesh="hogwarts_beams_"..spec.id..".obj",
        tiles={"hogwarts_beams_dark_oak.png"}, paramtype="light", paramtype2="facedir",
        sunlight_propagates=true, is_ground_content=false,
        groups={choppy=2,oddly_breakable_by_hand=2,hogwarts_beam=1},
        selection_box={type="fixed",fixed=anchor_boxes},collision_box={type="fixed",fixed=anchor_boxes},
        on_place=place,can_dig=can_dig,on_destruct=clear_parts,
        -- Generic screwdrivers must not bypass footprint checks.
        on_rotate=function() return false end,
    })
    for i,p in ipairs(spec.parts) do
        if not (p.offset[1]==0 and p.offset[2]==0 and p.offset[3]==0) then
            mt.register_node(prefix.."part_"..spec.id.."_"..i,{
                description="Hogwarts Beam (internal occupied space)",drawtype="nodebox",
                node_box={type="fixed",fixed={}},tiles={"hogwarts_beams_dark_oak.png"},
                paramtype="light",paramtype2="facedir",sunlight_propagates=true,
                walkable=true,pointable=true,buildable_to=false,is_ground_content=false,drop="",
                groups={not_in_creative_inventory=1,hogwarts_beam_part=1,choppy=2,oddly_breakable_by_hand=2},
                selection_box={type="fixed",fixed=p.boxes},collision_box={type="fixed",fixed=p.boxes},
                on_dig=function(pos,node,player)
                    local root=get_root(pos)
                    if root then mt.node_dig(root,mt.get_node(root),player) end
                end,
                on_rotate=function() return false end,
            })
        end
    end
end
mt.register_tool(prefix.."mallet",{
    description="Hogwarts Beam Mallet\nLeft-click: turn 90 degrees\nSneak + left-click: turn back",
    inventory_image="hogwarts_beams_mallet.png",on_use=turn,
    tool_capabilities={full_punch_interval=1,max_drop_level=0,groupcaps={}},
})
-- Generic wood recipes. Beam items are intentionally NOT in group:wood.
-- Starter pieces use one to six planks; longer timbers upgrade with one plank.
for _,spec in ipairs(specs) do
    local recipe={}
    if spec.length==1 then
        local count=({horizontal=1,post=2,brace=3})[spec.kind]+(spec.size=="heavy" and 3 or 0)
        for i=1,count do recipe[#recipe+1]="group:wood" end
    else
        recipe={prefix..spec.kind.."_"..spec.size.."_"..(spec.length-1),"group:wood"}
    end
    mt.register_craft({type="shapeless",output=prefix..spec.id,recipe=recipe})
end
mt.register_craft({type="shapeless",output=prefix.."mallet",recipe={"group:wood","group:stick"}})
local function cleanup(pos)
    local r=mt.deserialize(mt.get_meta(pos):get_string("root"))
    if type(r)~="table" or type(r.x)~="number" or type(r.y)~="number" or type(r.z)~="number" then
        mt.remove_node(pos); return
    end
    local node=mt.get_node_or_nil(r)
    if not node or node.name=="ignore" then return end -- Never delete for an unloaded anchor.
    local spec=by_name[node.name]
    if spec then
        for _,c in ipairs(cells(r,spec,node.param2%4)) do
            if key(c.pos)==key(pos) and mt.get_node(pos).name==prefix.."part_"..spec.id.."_"..c.index then return end
        end
    end
    mt.remove_node(pos)
end
mt.register_lbm({name=prefix.."clean_orphan_parts",nodenames={"group:"..part_group},run_at_every_load=true,action=cleanup})
mt.register_abm({label="Hogwarts beam orphan cleanup",nodenames={"group:"..part_group},interval=20,chance=1,action=cleanup})
