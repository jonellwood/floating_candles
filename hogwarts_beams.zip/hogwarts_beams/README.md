# Hogwarts Beams — Asuna / Luanti

Real dark timber meshes for the Great Hall. Version 1.0.

## Install on your Mac

1. Quit the world. Make a copy of the Hogwarts world folder before installing.
2. Unzip `hogwarts_beams.zip`. The mod folder must be named `hogwarts_beams`.
3. In Luanti's main menu, use **About > Open User Data Directory** if available.
   Put the entire `hogwarts_beams` folder inside that directory's `mods` folder.
   Create `mods` if it is missing. The resulting path must end in
   `mods/hogwarts_beams/mod.conf` — avoid nesting two `hogwarts_beams` folders.
4. Select your Asuna world. Click **Select mods** (or **Configure** on older
   versions), enable `hogwarts_beams`, then start the world.
5. Enable Creative Mode and search your inventory for **Hogwarts**.

A common macOS user data path is `~/Library/Application Support/minetest/`.
Use Finder > Go > Go to Folder (Command+Shift+G) to open it. The Luanti name
change did not necessarily rename existing data folders. Some portable
installations use the app's `Contents/User` directory instead; the main menu's
Open User Data Directory button avoids guessing.

Alternative: put the mod in `worlds/YOUR_WORLD/worldmods/hogwarts_beams/`.
World-specific mods are loaded for that world automatically. This is a regular
server/world mod, not a client-side mod; multiplayer installation belongs on
its server. You do not need to modify Asuna's game files.

## Included pieces

| Piece | Sizes | Lengths |
|---|---|---|
| 45-degree brace | Slim (1/4 block), Heavy (1/2 block) | 1–5 blocks across AND up |
| Horizontal beam | Slim, Heavy | 1–5 blocks along its axis |
| Vertical post | Slim, Heavy | 1–5 blocks high |
| Beam mallet | Rotation tool | Four horizontal directions |

30 placeable timber items, plus the mallet. All have an original dark oak
texture. Braces have smooth diagonal faces, not staircase geometry. Brace ends
are trimmed flush to their overall rise/run envelope. A 5-block brace has a
5-block horizontal run and a 5-block rise; its diagonal length is about 7.07
blocks. The long pieces are single timbers, not separate placed stair steps.

## Place and rotate

- Place a brace at its **LOW end**. It rises **away from you**, following the
  horizontal direction you are looking. Horizontal beams also extend away
  from you. Posts rise straight up.
- Looking due east makes it rise east; west makes it rise west. That gives you
  both sides of a roof without separate mirrored inventory items.
- Select the **Hogwarts Beam Mallet** and **left-click** any part of a timber
  to turn it 90 degrees. **Sneak + left-click** turns the other direction.
- Dig any part normally to remove the whole timber. In survival it drops one
  beam item; normal engine creative-drop behavior applies in Creative Mode.
- For a brace rising north/south, change which direction you face when placing.
- A generic screwdriver is intentionally disabled for these nodes. Use the
  mallet so collision and occupied-space checks stay in sync.

A long beam reserves the grid cells its timber crosses, including narrow cells
beside the diagonal. Placement and rotation require those cells to be empty
**air** and unprotected. The mod never replaces walls, plants, liquids or other
beams. If a message reports blocked clearance, move the anchor or use a shorter
piece. The empty-looking part of an occupied grid cell cannot contain a second
node; this is a limitation of Luanti's one-node-per-cell world model. Build the
beams first when working closely around roof blocks.

The visible faces are smooth. Collision and selection use small conservative
boxes along those faces (up to 1/16-block steps), so interaction is approximate.
Use the long braces for long spans: lining up 1-block diagonal pieces produces
narrower joints because their tips are trimmed to their own block envelopes.

## Quick first test

In Creative Mode, find:

- `Hogwarts Heavy 45-degree Brace (3 blocks)`
- `Hogwarts Heavy Horizontal Beam (3 blocks)`
- `Hogwarts Beam Mallet`

Place the brace on a temporary block in an open area, facing away from the
block. Its lowest cell is the placement anchor, and it rises three blocks in
that direction. Try the mallet, then dig a far end to check whole-beam removal.

With the `give` privilege, chat commands also work:

```
/giveme hogwarts_beams:brace_heavy_3 20
/giveme hogwarts_beams:brace_heavy_5 20
/giveme hogwarts_beams:horizontal_heavy_3 20
/giveme hogwarts_beams:post_heavy_3 20
/giveme hogwarts_beams:mallet
```

Item IDs follow `hogwarts_beams:KIND_SIZE_LENGTH` where KIND is `brace`,
`horizontal` or `post`, SIZE is `slim` or `heavy`, and LENGTH is 1–5.

## Great Hall starter frame

See `BEAM_PREVIEW.png` for renders of the actual supplied geometry and a sample
frame. This is a technical preview, not an in-game screenshot.

For a simple test frame, put the inner-facing wall blocks at **X=0** and
**X=13**. The open hall occupies X=1–12. Use any clear Z plane, e.g. **Z=0**.
These example coordinates are independent of your castle's existing floor plan.

| Part | Anchor node (X,Y,Z) | Item | Face while placing |
|---|---|---|---|
| Left brace | (1,8,0) | `brace_heavy_5` | East (+X) |
| Right brace | (12,8,0) | `brace_heavy_5` | West (-X) |
| Short tie between their high ends | (6,12,0) | `horizontal_heavy_2` | East (+X) |

The brace anchors are at Y=8; their uppermost centerline cells reach Y=12.
Together these pieces make a broad timber arch with a short horizontal tie.
Place temporary blocks below the anchors, place the beams, then remove the
scaffolding. Keep the entire sloped footprint clear while installing.

Repeat that frame every **4–5 blocks** along the hall's length, e.g. at
Z=0,5,10,15. Add separate lengthwise timbers or posts in neighboring free grid
cells. For true hammerbeam details, use shorter 1–3 block horizontals and braces
below the main frame; keep their node footprints separate. This starter is a
simple arch rather than a complete replica of the film set's roof.

## Survival crafting

All recipes are shapeless, using any `group:wood` planks:

| One-block starter | Planks |
|---|---:|
| Slim horizontal | 1 |
| Slim post | 2 |
| Slim brace | 3 |
| Heavy horizontal | 4 |
| Heavy post | 5 |
| Heavy brace | 6 |

Combine a beam with **one more plank** to upgrade to the next length, up to 5.
The kind and thickness stay the same. Craft the mallet from **one plank + one
stick** (`group:stick`). Creative Mode is the quickest route for your castle.

## Compatibility, checks and limits

- Uses the Luanti/Minetest node and Lua APIs; targets engine 5.4 or later.
- No required mods or Asuna-specific node IDs. Designed for Asuna, but runtime
  compatibility has not been confirmed in a live Asuna world here.
- Lua syntax checked. Automated mocked-API tests cover all 30 items in four
  directions, rotation, blocked/protected/unloaded placement, protected digging,
  creative consumption, complete removal, orphan cleanup, and unique recipes.
- Mesh checks cover watertight geometry, outward faces and footprint bounds.
- No live engine rendering, lighting, performance or multiplayer test was
  available. Try the first-test steps before filling the entire Great Hall.
- WorldEdit/schematic operations that bypass callbacks may break multi-node
  bookkeeping. Use normal placement/removal for these timbers. An orphan
  cleanup runs on load and every 20 seconds, deferring if the anchor is unloaded.
  It removes orphan placeholders, but does not reconstruct missing beam parts.
- Keep this mod enabled after building with it; removing it leaves unknown nodes.
- Roof pitches other than 45 degrees and decorative junction pieces are outside
  this first version.

## Files and editing

- `init.lua`: registration, placement, rotation, recipes and cleanup.
- `geometry.lua`: generated collision/selection data.
- `models/`: original OBJ timber meshes.
- `textures/`: original dark oak texture and mallet icon.
- `source/generate_assets.py`: reproducible mesh/texture generator (Python + Pillow).
- `source/test_mod.lua`: mocked-engine behavior checks (Lua 5.3, run with texlua).
- `source/verify_meshes.py`: geometry checks (Python standard library).
- `LICENSE.txt`: MIT license for code, models and textures.

To rebuild assets: `python3 source/generate_assets.py` from the mod folder.
To run behavior checks: `texlua source/test_mod.lua .` from the mod folder.

Official reference:
https://docs.luanti.org/for-players/installing-mods/
https://api.luanti.org/nodes/
