local rootpath=arg[1] or 'hogwarts_beams'
local nodes,metas,crafts,abms,lbms={},{},{},{},{}
local drops=0
local creative=false
local protected={}
local unloaded={}
local messages={}
local function k(p) return p.x..','..p.y..','..p.z end
local function serial(v)
 if type(v)=='table' then
  local keys={};for a in pairs(v) do keys[#keys+1]=a end
  table.sort(keys,function(a,b)return tostring(a)<tostring(b)end)
  local out={};for _,a in ipairs(keys) do out[#out+1]='['..serial(a)..']='..serial(v[a]) end
  return '{'..table.concat(out,',')..'}'
 elseif type(v)=='string' then return string.format('%q',v)
 else return tostring(v) end
end
minetest={registered_nodes={},registered_tools={}}
local mt=minetest
function mt.get_current_modname() return 'hogwarts_beams' end
function mt.get_modpath() return rootpath end
function mt.register_node(n,d) mt.registered_nodes[n]=d end
function mt.register_tool(n,d) mt.registered_tools[n]=d end
function mt.register_craft(d) crafts[#crafts+1]=d end
function mt.register_abm(d) abms[#abms+1]=d end
function mt.register_lbm(d) lbms[#lbms+1]=d end
function mt.get_node(p) return nodes[k(p)] or {name=unloaded[k(p)] and 'ignore' or 'air',param2=0} end
function mt.get_node_or_nil(p) if unloaded[k(p)] then return nil end;return mt.get_node(p) end
function mt.get_item_group(n,g) local d=mt.registered_nodes[n];return d and d.groups and d.groups[g] or 0 end
function mt.get_meta(p)
 local s=k(p);metas[s]=metas[s] or {};local t=metas[s]
 return {get_string=function(_,a)return t[a] or ''end,set_string=function(_,a,b)t[a]=b end}
end
function mt.serialize(v) return serial(v) end
function mt.deserialize(s) local f=load('return '..s,'serialized','t',{});if f then local ok,v=pcall(f);if ok then return v end end end
function mt.pos_to_string(p) return '('..k(p)..')' end
function mt.swap_node(p,n) nodes[k(p)]={name=n.name,param2=n.param2 or 0} end
function mt.set_node(p,n)
 local old=mt.get_node(p);local d=mt.registered_nodes[old.name]
 if d and d.on_destruct then d.on_destruct(p) end
 metas[k(p)]=nil;mt.swap_node(p,n)
end
function mt.remove_node(p) mt.set_node(p,{name='air'}) end
function mt.is_protected(p,n) return protected[k(p)] or false end
function mt.record_protection_violation() end
function mt.chat_send_player(n,s) messages[#messages+1]=s end
function mt.is_creative_enabled() return creative end
function mt.check_player_privs() return true end
function mt.dir_to_facedir(d) return d.r end
function mt.node_dig(p,n,player)
 local d=mt.registered_nodes[n.name]
 if d and d.can_dig and not d.can_dig(p,player) then return end
 mt.remove_node(p);drops=drops+1
end
mt.registered_nodes['test:stone']={groups={}}
local player={r=0,sneak=false}
function player:get_player_name() return 'tester' end
function player:get_player_control() return {sneak=self.sneak} end
function player:get_look_dir() return {r=self.r} end
local function stack(n,count)
 return {count=count or 1,get_name=function()return n end,take_item=function(s)s.count=s.count-1 end}
end
local function reset() nodes={};metas={};protected={};unloaded={};drops=0;messages={};creative=false;player.r=0;player.sneak=false end
local anchor={x=0,y=10,z=0}
local pointed={type='node',under={x=0,y=9,z=0},above=anchor}
local function place(n)
 nodes[k(pointed.under)]={name='test:stone',param2=0}
 local item=stack(n);mt.registered_nodes[n].on_place(item,player,pointed);return item
end
local function parts()
 local r={};for s,n in pairs(nodes) do if mt.get_item_group(n.name,'hogwarts_beam_part')==1 then r[#r+1]=s end end;return r
end
local function pos(s) local x,y,z=s:match('([^,]+),([^,]+),([^,]+)');return {x=tonumber(x),y=tonumber(y),z=tonumber(z)} end
local function assert_air_parts() assert(#parts()==0,'leftover helpers') end

dofile(rootpath..'/init.lua')
local specs=dofile(rootpath..'/geometry.lua')
assert(#specs==30)
local mallet=mt.registered_tools['hogwarts_beams:mallet']
local checks=0
for _,spec in ipairs(specs) do
 local n='hogwarts_beams:'..spec.id
 for r=0,3 do
  reset();player.r=r
  local item=place(n)
  assert(item.count==0 and mt.get_node(anchor).name==n,'place '..n)
  assert(mt.get_node(anchor).param2==r)
  assert(#parts()==#spec.parts-1)
  -- Full rotation must keep the same number of reserved cells.
  for j=1,4 do mallet.on_use(stack('hogwarts_beams:mallet'),player,{type='node',under=anchor});assert(#parts()==#spec.parts-1) end
  assert(mt.get_node(anchor).param2==r)
  player.sneak=true;mallet.on_use(stack('hogwarts_beams:mallet'),player,{type='node',under=anchor})
  assert(mt.get_node(anchor).param2==(r+3)%4)
  local pp=parts()
  if #pp>0 then local p=pos(pp[#pp]);local pn=mt.get_node(p);mt.registered_nodes[pn.name].on_dig(p,pn,player)
  else mt.node_dig(anchor,mt.get_node(anchor),player) end
  assert(mt.get_node(anchor).name=='air' and drops==1);assert_air_parts()
  checks=checks+1
 end
end
-- Clearance rejection must be atomic; no consumed item or partial placement.
local n='hogwarts_beams:brace_heavy_5'
reset();nodes['0,14,4']={name='test:stone',param2=0};assert(place(n).count==1);assert_air_parts();assert(mt.get_node(anchor).name=='air')
reset();protected['0,14,4']=true;assert(place(n).count==1);assert_air_parts()
reset();unloaded['0,14,4']=true;assert(place(n).count==1);assert_air_parts()
reset();creative=true;assert(place(n).count==1);assert(mt.get_node(anchor).name==n)
-- Rotation failure leaves the original footprint intact.
reset();place(n);local old=serial(nodes);nodes['4,14,0']={name='test:stone',param2=0};local before=serial(nodes)
mallet.on_use(stack('hogwarts_beams:mallet'),player,{type='node',under=anchor});assert(serial(nodes)==before)
-- A protected distant cell also blocks digging the anchor and rotating.
reset();place(n);protected['0,14,4']=true;local before=serial(nodes)
mt.node_dig(anchor,mt.get_node(anchor),player);assert(serial(nodes)==before)
mallet.on_use(stack('hogwarts_beams:mallet'),player,{type='node',under=anchor});assert(serial(nodes)==before)
-- Constructor-independent external deletion cleans helpers; bulk deletion gets ABM cleanup.
reset();place(n);mt.remove_node(anchor);assert_air_parts()
reset();place(n);nodes[k(anchor)]={name='air',param2=0}
for _,s in ipairs(parts()) do abms[1].action(pos(s)) end;assert_air_parts()
reset();place(n);local pp=parts();nodes[k(anchor)]=nil;unloaded[k(anchor)]=true
for _,s in ipairs(pp) do lbms[1].action(pos(s)) end;assert(#parts()==#pp)
-- Recipes fit normal 3x3 crafting grids and have no duplicate multisets.
local seen={}
for _,c in ipairs(crafts) do
 assert(#c.recipe<=9)
 local rr={table.unpack(c.recipe)};table.sort(rr);local s=table.concat(rr,'|')
 assert(not seen[s],'duplicate recipe: '..s);seen[s]=true
end
print('PASS: '..checks..' beam/orientation cases; blocked placement and rotation; protected digging; creative mode; whole-beam cleanup; unloaded orphan handling; '..#crafts..' unique recipes.')
