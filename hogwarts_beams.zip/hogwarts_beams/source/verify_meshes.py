"""Verify supplied convex OBJ prisms are closed and face outward."""
from pathlib import Path
from collections import Counter
root=Path(__file__).resolve().parents[1]
files=sorted((root/'models').glob('*.obj'))
assert len(files)==30
for p in files:
    vs=[];fs=[]
    for line in p.read_text().splitlines():
        a=line.split()
        if a and a[0]=='v': vs.append(tuple(map(float,a[1:])))
        if a and a[0]=='f': fs.append(tuple(int(x.split('/')[0])-1 for x in a[1:]))
    edges=Counter(tuple(sorted((a,b))) for f in fs for a,b in zip(f,f[1:]+f[:1]))
    assert all(n==2 for n in edges.values()),f'{p.name}: non-manifold edge'
    c=tuple(sum(v[j] for v in vs)/len(vs) for j in range(3))
    volume=0
    for f in fs:
        a,b,d=[vs[i] for i in f];u=[b[j]-a[j] for j in range(3)];v=[d[j]-a[j] for j in range(3)]
        normal=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
        m=tuple((a[j]+b[j]+d[j])/3 for j in range(3))
        assert sum(normal[j]*(m[j]-c[j]) for j in range(3))>1e-9,f'{p.name}: inward/degenerate face'
        volume+=sum(a[j]*(b[(j+1)%3]*d[(j+2)%3]-b[(j+2)%3]*d[(j+1)%3]) for j in range(3))/6
    assert volume>0
    n=int(p.stem.rsplit('_',1)[1]);kind=p.stem.split('_')[2]
    assert min(v[1] for v in vs)>=-.5000001 and max(v[1] for v in vs)<=n-.5+1e-7
    assert min(v[2] for v in vs)>=-.5000001 and max(v[2] for v in vs)<=n-.5+1e-7
print(f'PASS: {len(files)} watertight, outward-wound OBJ meshes within their rise/run bounds.')
